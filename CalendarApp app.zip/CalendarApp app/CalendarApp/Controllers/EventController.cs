using Microsoft.AspNetCore.Mvc;
using CalendarApp.Models;
using System.Linq;
using System.Threading.Tasks;

public class EventsController : Controller
{
    private readonly CalendarContext _context;

    public EventsController(CalendarContext context)
    {
        _context = context;
    }

    // Get events for a selected date
    public IActionResult Index(DateTime? selectedDate)
    {
        if (selectedDate == null)
        {
            selectedDate = DateTime.Today;
        }

        var events = _context.Events.Where(e => e.Date == selectedDate).ToList();
        ViewBag.SelectedDate = selectedDate.Value.ToString("yyyy-MM-dd");
        return View(events);
    }

    // Show form to create a new event
    public IActionResult Create()
    {
        return View();
    }

    // Handle event creation
    [HttpPost]
    public async Task<IActionResult> Create(Event @event)
    {
        if (ModelState.IsValid)
        {
            _context.Add(@event);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index), new { selectedDate = @event.Date });
        }
        return View(@event);
    }
}
